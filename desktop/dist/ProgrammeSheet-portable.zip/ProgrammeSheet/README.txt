Programme Sheet Builder — standalone on Windows

This folder IS the app. There is no installer .exe (Smart App Control blocks
those when they are unsigned).

On your PC
----------
1. If this came as a zip from the internet: right-click the zip → Properties
   → tick Unblock → Apply → extract.
2. Open the ProgrammeSheet folder.
3. Double-click Install.cmd
4. Use the Desktop shortcut "Programme Sheet Builder" after that.

To share
--------
Send ProgrammeSheet-portable.zip, or copy the whole extracted folder onto
a USB stick. On the other PC, Unblock the zip if it was downloaded, then
Install.cmd (or START.cmd once).

A USB copy of the folder (not via Downloads) usually has no "downloaded from
the internet" flag.

START.cmd opens the builder without installing. Close the window to quit.
Needs Microsoft Edge or Chrome. Works offline. Club Setup and the working sheet stay on
that Windows user account.

Open-online.cmd opens the live website and needs internet.
